// Usage: node set-domain.js https://your-site.com   (replaces the placeholders in www/)
const fs=require("fs"),path=require("path");const u=(process.argv[2]||"").replace(/\/$/,"");const e=process.argv[3]||"";
if(!/^https?:\/\//.test(u)){console.log("Usage: node set-domain.js https://your-site.com you@email.com");process.exit(1)}
for(const f of ["index.html","robots.txt","sitemap.xml","privacy.html","terms.html"]){const p=path.join("www",f);let s=fs.readFileSync(p,"utf8").split("https://YOUR-SITE-URL").join(u);if(e)s=s.split("YOUR-EMAIL@example.com").join(e);fs.writeFileSync(p,s)}
console.log("Done. Domain set to",u);
