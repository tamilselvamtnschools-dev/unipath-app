const { app, BrowserWindow, Menu, shell, ipcMain } = require("electron");
const path = require("path"), fs = require("fs"), http = require("http"), crypto = require("crypto");
function cfg() {
  try { const t = fs.readFileSync(path.join(__dirname, "..", "www", "config.js"), "utf8"); return JSON.parse(t.slice(t.indexOf("{"), t.lastIndexOf("}") + 1)); } catch (e) { return {}; }
}
const b64 = (b) => b.toString("base64url");
// Google sign-in for Windows: system browser + loopback redirect + PKCE
ipcMain.handle("google-login", () => new Promise((resolve, reject) => {
  const c = cfg(); if (!c.googleDesktopClientId) return reject(new Error("setup"));
  const verifier = b64(crypto.randomBytes(32)), state = b64(crypto.randomBytes(16));
  const challenge = b64(crypto.createHash("sha256").update(verifier).digest());
  const srv = http.createServer(async (req, res) => {
    const u = new URL(req.url, "http://127.0.0.1"); const code = u.searchParams.get("code");
    if (!code) { res.end(); return; }
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.end("<h3 style='font-family:sans-serif'>Signed in. You can close this tab and return to UniPath.</h3>");
    clearTimeout(timer); srv.close();
    try {
      if (u.searchParams.get("state") !== state) throw new Error("state mismatch");
      const body = new URLSearchParams({ code, client_id: c.googleDesktopClientId, client_secret: c.googleDesktopClientSecret || "", code_verifier: verifier, grant_type: "authorization_code", redirect_uri: "http://127.0.0.1:" + srv.address().port });
      const r = await (await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body })).json();
      if (!r.id_token) throw new Error(r.error_description || r.error || "no token");
      const p = JSON.parse(Buffer.from(r.id_token.split(".")[1], "base64url").toString());
      resolve({ name: p.name || p.email, email: p.email });
    } catch (e) { reject(e); }
  });
  const timer = setTimeout(() => { srv.close(); reject(new Error("timed out")); }, 180000);
  srv.listen(0, "127.0.0.1", () => {
    const redirect = "http://127.0.0.1:" + srv.address().port;
    shell.openExternal("https://accounts.google.com/o/oauth2/v2/auth?" + new URLSearchParams({ client_id: c.googleDesktopClientId, redirect_uri: redirect, response_type: "code", scope: "openid email profile", code_challenge: challenge, code_challenge_method: "S256", state }));
  });
}));
if (!app.requestSingleInstanceLock()) app.quit();
let win;
function create() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1100, height: 800, minWidth: 380, minHeight: 600,
    backgroundColor: "#0e4f5c", title: "UniPath World",
    icon: path.join(__dirname, "..", "assets", "icon.ico"),
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, sandbox: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, "..", "www", "index.html"));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: "deny" }; });
  win.webContents.on("will-navigate", (e, url) => { if (/^https?:/.test(url)) { e.preventDefault(); shell.openExternal(url); } });
}
app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(create);
app.on("window-all-closed", () => app.quit());
