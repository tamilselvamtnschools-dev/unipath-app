const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("unipathDesktop", { googleLogin: () => ipcRenderer.invoke("google-login") });
