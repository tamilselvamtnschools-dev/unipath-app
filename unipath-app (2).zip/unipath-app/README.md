# UniPath World – Windows + Android app

One codebase (`www/index.html`) packaged two ways:
- **Windows**: Electron -> installer (`.exe`) and portable `.exe`
- **Android**: Capacitor -> `.apk`
- Also installable as a PWA from any browser (manifest + offline service worker).

## Easiest: build in the cloud (no tools needed)
1. Create a free GitHub repo and upload everything in this folder.
2. Open the **Actions** tab -> **Build apps** -> **Run workflow**.
3. After ~10 min download `UniPath-Windows` (.exe) and `UniPath-Android` (.apk) from the run page.

## Build locally
Needs Node 20+; Android also needs Android Studio (JDK 21).
```
npm install
npm run start            # test the desktop app
npm run win              # -> dist/*.exe   (run on Windows)
npm run android:init     # once: creates android/ project + icons
npm run android:sync     # after editing www/
npm run android:open     # opens Android Studio -> Build > Build APK
```
To install the APK: copy it to the phone and allow "install unknown apps".
For Play Store release, build a signed AAB in Android Studio.

## Notes
- The claude.ai sign-in button is hidden (it only works inside claude.ai); "Continue as guest" works everywhere.
- Edit only `www/index.html`; both apps use it.

## Google sign-in setup (needed once)
Sign-in buttons work only after you add your own Google client IDs to `www/config.js`.
1. Go to https://console.cloud.google.com -> create a project -> **APIs & Services -> OAuth consent screen** (External, add your email as test user).
2. **Credentials -> Create credentials -> OAuth client ID**, then create:
   - **Web application**: add your site URL under *Authorized JavaScript origins* -> put its ID in `googleWebClientId` (used for the browser/PWA and as the server ID for Android).
   - **Desktop app** -> put its ID and secret in `googleDesktopClientId` / `googleDesktopClientSecret` (Windows app).
   - **Android**: package name `com.unipath.world` plus the SHA-1 of your signing key (`keytool -list -v -keystore ~/.android/debug.keystore -storepass android`; the CI debug APK uses a different key each run, so for CI builds add a fixed keystore).
3. Rebuild. Guest mode always works without any of this.

## Put it online as a website (pick one, all free)
Your site is the `www/` folder. It has SEO tags, social-share image, favicon, privacy + terms pages (required for Google sign-in), a 404 page, sitemap/robots, an install button and offline support.
- **GitHub Pages (automatic)**: repo -> Settings -> Pages -> Source: *GitHub Actions*. Pushing to `main` deploys it to `https://<you>.github.io/<repo>/`.
- **Netlify**: drag the `www` folder onto https://app.netlify.com/drop (or connect the repo; `netlify.toml` is included).
- **Vercel / Cloudflare Pages**: import the repo, output directory `www`.

Before sharing: run `node set-domain.js https://your-site-url you@email.com` (fills in the canonical URL, share links, sitemap and the contact email; the GitHub Pages workflow sets the URL automatically). Then use the same URL as the *Authorized JavaScript origin* and the privacy/terms links on the Google consent screen. For a custom domain, buy one and add it in your host's settings.
