// Google sign-in settings. See README.md ("Google sign-in setup"). Leave "" to disable.
window.UNIPATH_CONFIG = {
  "googleWebClientId": "",
  "googleDesktopClientId": "",
  "googleDesktopClientSecret": ""
};
