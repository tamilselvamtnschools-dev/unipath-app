# UniPath World – Windows + Android app

One codebase (`www/index.html`) packaged two ways:
- **Windows**: Electron -> installer (`.exe`) and portable `.exe`
- **Android**: Capacitor -> `.apk`
- Also installable as a PWA from any browser (manifest + offline service worker).

## Easiest: build in the cloud (no tools needed)
1. Create a free GitHub repo and upload everything in this folder.
2. Open the **Actions** tab -> **Build apps** -> **Run workflow**.
3. After ~10 min download `UniPath-Windows` (.exe) and `UniPath-Android` (.apk) from the run page.

## Build locally
Needs Node 20+; Android also needs Android Studio (JDK 21).
```
npm install
npm run start            # test the desktop app
npm run win              # -> dist/*.exe   (run on Windows)
npm run android:init     # once: creates android/ project + icons
npm run android:sync     # after editing www/
npm run android:open     # opens Android Studio -> Build > Build APK
```
To install the APK: copy it to the phone and allow "install unknown apps".
For Play Store release, build a signed AAB in Android Studio.

## Notes
- The claude.ai sign-in button is hidden (it only works inside claude.ai); "Continue as guest" works everywhere.
- Edit only `www/index.html`; both apps use it.
